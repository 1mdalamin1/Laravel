<h4>Hello,<strong style="color: green; font-size: 24px;"> {{$contact->name}} !</strong></h4>

<p>We have received your message. This is what you sent.</p>

<p>
    Name: {{$contact->name}}<br/>
    Email: {{$contact->email}}<br/>
    Phone: {{$contact->phone}}<br/>
    Message: {{$contact->message}}<br/>
</p>


<p><strong style="color: green;">We will reply you soon.</strong> In the meanwhile you can call us following number.</p>
<h2><img width="120" src="/img/logo.png" alt=""></h2>
