<h4>Hello,<strong style="color: green; font-size: 24px;"> <?php echo e($contact->name); ?> !</strong></h4>

<p>We have received your message. This is what you sent.</p>

<p>
    Name: <?php echo e($contact->name); ?><br/>
    Email: <?php echo e($contact->email); ?><br/>
    Phone: <?php echo e($contact->phone); ?><br/>
    Message: <?php echo e($contact->message); ?><br/>
</p>


<p><strong style="color: green;">We will reply you soon.</strong> In the meanwhile you can call us following number.</p>
<h2><img src="" alt="" srcset=""></h2>
<?php /**PATH D:\virza\htdocs\Laravel\civanoglu\resources\views/emails/contact-mail.blade.php ENDPATH**/ ?>