<?php $__env->startSection('app_content'); ?>

<?php if ($__env->exists('inc.backend.sidebar')) echo $__env->make('inc.backend.sidebar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

<!-- Content Wrapper -->
<div id="content-wrapper" class="d-flex flex-column">

    <!-- Main Content -->
    <div id="content">

        <!-- Topbar -->
       <?php echo $__env->make('inc.backend.topbar', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <!-- End of Topbar -->

        <!-- Begin Page Content -->
        <div class="container-fluid">

            <!-- Page Heading -->
            <?php echo $__env->yieldContent('master_content'); ?>

        </div>
        <!-- /.container-fluid -->

    </div>
    <!-- End of Main Content -->

    <!-- Footer -->
    <?php echo $__env->make('inc.backend.footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <!-- End of Footer -->

</div>
<!-- End of Content Wrapper -->

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\virza\htdocs\socialAuthentication\e-project\resources\views/layouts/backend_master.blade.php ENDPATH**/ ?>