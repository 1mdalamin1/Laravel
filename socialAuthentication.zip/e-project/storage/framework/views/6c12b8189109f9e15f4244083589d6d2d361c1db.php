<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('master_content'); ?>

<h1>Dashboard</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi consequatur consequuntur earum unde temporibus facilis doloremque dignissimos ipsa perspiciatis, eveniet eius, ipsum minima a corporis odio porro, voluptas saepe eos?</p>



<?php $__env->stopSection(); ?>

<?php $__env->startPush('css'); ?>

<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.backend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\virza\htdocs\socialAuthentication\e-project\resources\views/dashboard.blade.php ENDPATH**/ ?>