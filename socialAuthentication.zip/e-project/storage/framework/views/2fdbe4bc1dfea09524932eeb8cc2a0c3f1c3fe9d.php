





<?php /**PATH D:\virza\htdocs\socialAuthentication\e-project\resources\views/welcome.blade.php ENDPATH**/ ?>