<?php $__env->startSection('app_content'); ?>

<?php
    // dd($numbers);
?>
 <?php echo e($numbers[0]); ?>

 { !! $text !! }
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\virza\htdocs\socialAuthentication\e-project\resources\views/index.blade.php ENDPATH**/ ?>