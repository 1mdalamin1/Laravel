<?php $__env->startSection('app_content'); ?>

<h1>Login</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi consequatur consequuntur earum unde temporibus facilis doloremque dignissimos ipsa perspiciatis, eveniet eius, ipsum minima a corporis odio porro, voluptas saepe eos?</p>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend_app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\virza\htdocs\socialAuthentication\e-project\resources\views/login.blade.php ENDPATH**/ ?>