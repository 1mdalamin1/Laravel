@extends('layouts.backend_app')

@section('app_content')

@php
    // dd($numbers);
@endphp
 {{ $numbers[0]}}
 { !! $text !! }
@endsection
