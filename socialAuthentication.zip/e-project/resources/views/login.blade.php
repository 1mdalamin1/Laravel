@extends('layouts.backend_app')

@section('app_content')

<h1>Login</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi consequatur consequuntur earum unde temporibus facilis doloremque dignissimos ipsa perspiciatis, eveniet eius, ipsum minima a corporis odio porro, voluptas saepe eos?</p>



@stop
