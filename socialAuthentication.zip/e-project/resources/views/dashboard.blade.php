@extends('layouts.backend_master')
@section('title', 'Dashboard')
@section('master_content')

<h1>Dashboard</h1>
<p>Lorem ipsum dolor sit amet consectetur adipisicing elit. Modi consequatur consequuntur earum unde temporibus facilis doloremque dignissimos ipsa perspiciatis, eveniet eius, ipsum minima a corporis odio porro, voluptas saepe eos?</p>



@stop

@push('css')

@endpush
