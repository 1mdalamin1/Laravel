// export default {
//   data() {
//     return {
//       voteScores:
//     };
//   }
// };
