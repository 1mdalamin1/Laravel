import Vue from "vue";

import { Tabs, Tab } from "vue-simple-tabs";
Vue.component("Tabs", Tabs);
Vue.component("Tab", Tab);
