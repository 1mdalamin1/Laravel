module.exports = {
  future: {},
  purge: [],
  theme: {
    extend: {
      colors: {
        primary: "#CEE3F8",
        primaryLight: "#EFF7FF",
        primaryDark: "#4f86b5",
        primaryDark2: "#4270a2"
      }
    }
  },
  variants: {},
  plugins: []
};
