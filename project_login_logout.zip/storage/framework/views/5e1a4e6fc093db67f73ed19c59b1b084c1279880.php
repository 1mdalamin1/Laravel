<aside class="control-sidebar control-sidebar-dark">
    <!-- Control sidebar content goes here -->
</aside>
<?php /**PATH D:\virza\htdocs\Laravel\project\resources\views/backend/inc/right.blade.php ENDPATH**/ ?>