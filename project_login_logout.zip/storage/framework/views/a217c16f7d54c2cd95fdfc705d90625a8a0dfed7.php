<?php $__env->startSection('title', 'Admin Dashboard'); ?>

<?php $__env->startSection('master_content'); ?>

<h1>Admin Dashboard</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.backend_master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\virza\htdocs\Laravel\project\resources\views/backend/dashboard.blade.php ENDPATH**/ ?>